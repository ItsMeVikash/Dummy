package MixedNumber;

public class Fraction {
	private int whole;
	private int numerator;
	private int denominator;

	public Fraction() {

		whole = 0;
		numerator = 0;
		denominator = 1;
	}

	public Fraction(int numerator, int denominator) {

		if (denominator != 0) {
			this.numerator = numerator;
			this.denominator = denominator;
			whole = 0;
		} else
			System.exit(0);

	}

	public Fraction(int whole, int numerator, int denominator) {
		if (denominator != 0) {
			this.numerator = numerator;
			this.denominator = denominator;
			this.whole = whole;
		} else
			System.exit(0);
	}

	int gcd(int a, int b) {
		if (b == 0)
			return a;
		return gcd(b, a % b);
	}

	public Fraction reduce(int numerator, int denominator) {
		try {
			int gcdNum = gcd(numerator, denominator);
			denominator = denominator / gcdNum;
			numerator = numerator / gcdNum;
		} catch (Exception e) {
		}
		return new Fraction(numerator, denominator);
	}

	public Fraction add(Fraction A) {
		int numerator = (this.numerator * A.denominator) +(A.numerator * this.denominator); 
          System.out.println(numerator);
          int denominator = this.denominator * A.denominator;
          return reduce(numerator,denominator);

    }

	public Fraction substract(Fraction A){
         System.out.println("fraction");
          int numerator = (this.numerator * A.denominator);
          int denominator = this.denominator *A.denominator; 
          return reduce(numerator,denominator);
  }

	public Fraction multiply(Fraction A) {
		System.out.println("fraction");
		int numerator = this.numerator * A.numerator;
		int denominator = this.denominator * A.denominator;
		return reduce(numerator, denominator);
	}

	public Fraction divide(Fraction A) {
		System.out.println("fraction");
		int numerator = this.numerator * A.denominator;
		int denominator = this.denominator * A.numerator;
		return reduce(numerator, denominator);
	}

	public String toString() {
		if (numerator > denominator && denominator > 1)
			return (whole + numerator + "/" + denominator + " or " + (numerator / denominator) + " " + (numerator % denominator)
					+ "/" + denominator);
		else
			return (numerator + "/" + denominator);

	}

}